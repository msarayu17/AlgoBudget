import { useState } from "react"

export default function ExpenseForm({ budget, addExpense }) {

    const [amount, setAmount] = useState("")
    const [category, setCategory] = useState("")

    const handleSubmit = (e) => {
        e.preventDefault()

        if (!amount || !category) {
            alert("Please enter a category")
            return
        }

        if (!budget) {
            alert("Please set your monthly budget first")
            return
        }

        const newExpense = {
            amount: Number(amount),
            category: category,
            date: new Date().toLocaleDateString("en-CA")
        }

        addExpense(newExpense)

        setAmount("")
        setCategory("")
    }

    return (
        <form onSubmit={handleSubmit}>

            <input
                type="number"
                placeholder="Expense Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
            />

            <input
                type="text"
                placeholder="Category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
            />

            <button type="submit">
                Add Expense
            </button>

        </form>
    )
}