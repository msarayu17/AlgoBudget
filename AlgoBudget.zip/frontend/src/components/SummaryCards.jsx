export default function SummaryCards({ budget, expenses }) {

    const remaining = budget - expenses

    return (

        <div className="grid grid-cols-4 gap-6">

            <div className="bg-white p-6 rounded shadow">
                <p>Total Budget</p>
                <h3 className="text-2xl font-bold">₹{budget}</h3>
            </div>

            <div className="bg-white p-6 rounded shadow">
                <p>Total Expenses</p>
                <h3 className="text-red-500 text-2xl font-bold">₹{expenses}</h3>
            </div>

            <div className="bg-white p-6 rounded shadow">
                <p>Remaining</p>
                <h3 className="text-emerald-600 text-2xl font-bold">₹{remaining}</h3>
            </div>

            <div className="bg-white p-6 rounded shadow">
                <p>Savings</p>
                <h3 className="text-indigo-600 text-2xl font-bold">₹{remaining}</h3>
            </div>

        </div>

    )

}