export default function Header() {

    return (

        <div className="mb-8">

            <h2 className="text-3xl font-semibold">
                Hello 👋
            </h2>

            <p className="text-slate-500">
                Track today, relax tomorrow.
            </p>

        </div>

    )

}