import Calendar from "react-calendar"
import "react-calendar/dist/Calendar.css"

export default function ExpenseCalendar({ expenses = [] }) {

    const getExpenseForDate = (date) => {

        const formattedDate = date.toLocaleDateString("en-CA")

        return expenses
            .filter(e => {
                const dbDate = new Date(e.date).toLocaleDateString("en-CA")
                return dbDate === formattedDate
            })
            .reduce((sum, e) => sum + Number(e.amount), 0)
    }
    return (

        
        <div className="bg-white p-6 rounded shadow mt-10">

            <h3 className="text-xl mb-4">
                Monthly Expense Calendar
            </h3>

            <Calendar
                tileContent={({ date }) => {
                    const total = getExpenseForDate(date)

                    if (total > 0) {
                        return (
                            <p style={{ color: "green", fontSize: "12px" }}>
                                ₹{total}
                            </p>
                        )
                    }

                    return null
                }}
            />

        </div>
    )
}