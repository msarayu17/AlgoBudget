import { Link } from "react-router-dom"
import "./Sidebar.css"

export default function Sidebar() {
    return (
        <div className="sidebar">

            <h2 className="logo">AlgoBudget</h2>

            <nav className="nav-links">
                <Link to="/dashboard">Home</Link>
                <Link to="/transactions">Transactions</Link>
                <Link to="/reports">Reports</Link>
                <Link to="/profile">Profile</Link>
                <Link to="/settings">Settings</Link>
            </nav>

        </div>
    )
}