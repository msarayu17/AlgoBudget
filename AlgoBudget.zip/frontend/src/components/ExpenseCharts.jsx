import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts"

const COLORS = ["#10b981", "#6366f1", "#f43f5e", "#f59e0b"]

export default function ExpenseCharts({ expenses = [] }) {

    const categoryData = {}

    expenses.forEach((expense) => {
        const category = expense.category
        const amount = Number(expense.amount)

        if (categoryData[category]) {
            categoryData[category] += amount
        } else {
            categoryData[category] = amount
        }
    })

    const data = Object.keys(categoryData).map((key) => ({
        category: key,
        amount: categoryData[key]
    }))

    return (

        <div className="grid grid-cols-2 gap-10 mt-10">

            <PieChart width={300} height={300}>
                <Pie data={data} dataKey="amount" outerRadius={100}>
                    {data.map((entry, index) => (
                        <Cell key={index} fill={COLORS[index % COLORS.length]} />
                    ))}
                </Pie>
            </PieChart>

            <BarChart width={300} height={300} data={data}>
                <XAxis dataKey="category" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="amount">
                    {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                </Bar>
            </BarChart>
        </div>

    )
}