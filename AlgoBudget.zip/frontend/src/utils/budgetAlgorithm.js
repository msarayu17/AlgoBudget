export function checkBudget(totalExpense, budget) {

    const percent = (totalExpense / budget) * 100

    if (percent >= 70) {

        alert("Warning: 70% of your monthly budget is already used")

    }

}