import { useNavigate } from "react-router-dom"

export default function Landing() {

    const navigate = useNavigate()

    return (

        <div className="landing-container">

            <div className="landing-card">

                <h1 className="landing-title">AlgoBudget</h1>

                <p className="landing-tagline">
                    Code Your Cash Flow
                </p>

                <button
                    className="landing-btn"
                    onClick={() => navigate("/signup")}
                >
                    Get Started
                </button>

            </div>

        </div>
    )
}