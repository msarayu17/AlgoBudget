import { useEffect, useState } from "react"
import Sidebar from "../components/Sidebar"
import ExpenseCharts from "../components/ExpenseCharts"

export default function Reports() {

    const [expenses, setExpenses] = useState([])

    useEffect(() => {
        const savedExpenses = localStorage.getItem("expenses")
        if (savedExpenses) {
            setExpenses(JSON.parse(savedExpenses))
        }
    }, [])

    return (

        <div className="app-container">

            <Sidebar />

            <div className="main-content">

                <h1 className="text-2xl font-bold mb-4">Reports</h1>

                <div className="card">
                    <ExpenseCharts expenses={expenses} />
                </div>

            </div>

        </div>
    )
}