import { useState } from "react"
import { useNavigate } from "react-router-dom"

export default function Login() {

    const navigate = useNavigate()

    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [error, setError] = useState("")

    const handleLogin = async (e) => {
        e.preventDefault()

        try {
            const response = await fetch("http://127.0.0.1:5000/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ email, password })
            })

            const data = await response.json()

            if (response.ok) {
                // store user
                localStorage.setItem("user", JSON.stringify(data.user))
                localStorage.setItem("email", data.user.email)

                navigate("/dashboard")
            } else {
                setError(data.error)
            }

        } catch (err) {
            setError("Server error")
        }
    }

    return (
        <div className="center-page">
            <div className="login-card">
                <h2>Login</h2>

                <form onSubmit={handleLogin}>

                    <input
                        type="email"
                        placeholder="Enter Gmail"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />

                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />

                    {error && <p className="error">{error}</p>}

                    <button type="submit">Login</button>

                </form>

                <p style={{ marginTop: "10px", fontSize: "15px" }}>
                    Don't have an account?{" "}
                    <span
                        style={{ color: "blue", cursor: "pointer" }}
                        onClick={() => navigate("/signup")}
                    >
                        Sign up
                    </span>
                </p>

            </div>
        </div>
    )
}