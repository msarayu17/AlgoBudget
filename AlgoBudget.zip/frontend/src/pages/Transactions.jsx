import { useEffect, useState } from "react"
import Sidebar from "../components/Sidebar"

export default function Transactions() {

    const [expenses, setExpenses] = useState([])

    useEffect(() => {

        const fetchExpenses = async () => {
            try {
                const res = await fetch(
                    `http://127.0.0.1:5000/get-expenses?email=${localStorage.getItem("email")}`
                )

                const data = await res.json()
                if (data && data.length > 0) {
                    setExpenses(data)
                    localStorage.setItem("expenses", JSON.stringify(data))
                }

            } catch (error) {
                console.error(error)

                // fallback
                const savedExpenses = localStorage.getItem("expenses")
                if (savedExpenses) {
                    setExpenses(JSON.parse(savedExpenses))
                }
            }
        }

        fetchExpenses()

    }, [])

    return (

        <div className="app-container">

            <Sidebar />

            <div className="main-content">

                <h2 className="text-xl font-bold mb-4">All Transactions</h2>

                {expenses.length === 0 ? (
                    <p>No transactions yet 😭</p>
                ) : (


                    <div className="card">

                    <table className="w-full border">
                            

                        <thead>
                            <tr className="bg-gray-200 dark-header">
                                <th className="p-2">Date</th>
                                <th className="p-2">Category</th>
                                <th className="p-2">Amount</th>
                            </tr>
                        </thead>

                        <tbody>

                            {expenses.map((expense, index) => (

                                <tr key={index} className="text-center border-t">

                                    <td className="p-2">
                                        {new Date(expense.date).toISOString().split("T")[0]}
                                    </td>
                                    <td className="p-2">{expense.category}</td>
                                    <td className="p-2">₹{expense.amount}</td>

                                </tr>

                            ))}

                        </tbody>

                    </table>
</div>
                )}

                

            </div>

        </div>

    )
}