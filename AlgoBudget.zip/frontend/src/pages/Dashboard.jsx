import { useState, useEffect, useRef } from "react"
import Sidebar from "../components/Sidebar"
import Header from "../components/Header"
import SummaryCards from "../components/SummaryCards"
import ExpenseForm from "../components/ExpenseForm"
import ExpenseCalendar from "../components/ExpenseCalendar"
import ExpenseCharts from "../components/ExpenseCharts"

export default function Dashboard() {

    const [budget, setBudget] = useState(() => {
        const savedBudget = localStorage.getItem("budget")
        return savedBudget ? JSON.parse(savedBudget) : ""
    })
    const [expenses, setExpenses] = useState(() => {
        const saved = localStorage.getItem("expenses")
        return saved ? JSON.parse(saved) : []
    })

    const prevTotalRef = useRef(0)

    // clear old data when project starts

    useEffect(() => {
        localStorage.setItem("budget", JSON.stringify(budget))
    }, [budget])
    
    const addExpense = async (newExpense) => {
        const email = localStorage.getItem("email")

        if (!email) {
            alert("No email found. Please reload or login again.")
            return
        }

        const updated = [...expenses, newExpense]
        setExpenses(updated)
        localStorage.setItem("expenses", JSON.stringify(updated))

        try {
            const res = await fetch("http://127.0.0.1:5000/add-expense", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email: email,
                    date: newExpense.date,
                    amount: Number(newExpense.amount),
                    category: newExpense.category
                })
            })

            if (!res.ok) {
                const err = await res.json()
                console.log("SERVER ERROR:", err)
            }

        } catch (error) {
            console.error(error)
        }
    }

    const totalExpenses = expenses.reduce((sum, e) => sum + Number(e.amount), 0)
    useEffect(() => {

        if (
            budget &&
            prevTotalRef.current < budget * 0.7 &&
            totalExpenses >= budget * 0.7
        ) {
            alert("Warning: You have used more than 70% of your budget!")
        }

        prevTotalRef.current = totalExpenses

    }, [totalExpenses, budget])

    useEffect(() => {
        localStorage.removeItem("budgetWarning")
    }, [budget])

    useEffect(() => {
        const fetchExpenses = async () => {
            try {
                const email = localStorage.getItem("email")

                console.log("EMAIL:", email)

                if (!email) return

                const res = await fetch(
                    `http://127.0.0.1:5000/get-expenses?email=${email}`
                )

                const data = await res.json()

                console.log("BACKEND DATA:", data)

                // 🚨 ONLY overwrite if backend has data
                if (data && data.length > 0) {
                    setExpenses(data)
                    localStorage.setItem("expenses", JSON.stringify(data))
                }

            } catch (err) {
                console.error(err)
            }
        }

        fetchExpenses()
    }, [])

    return (

        <div className="app-container">

            <Sidebar />

            <div className="main-content">

                <Header />

                <h1 className="page-title">Dashboard</h1>

                <div className="card">

                    <h3>Set Monthly Budget</h3>

                    <input
                        type="number"
                        placeholder="Enter Monthly Budget"
                        value={budget}
                        onChange={(e) => setBudget(e.target.value)}
                    />

                </div>

                <SummaryCards
                    budget={budget}
                    expenses={totalExpenses}
                />

                <div className="card">

                    <ExpenseForm
                        budget={budget}
                        addExpense={addExpense}
                    />

                </div>

                <div className="card">
                    <ExpenseCalendar expenses={expenses} />
                </div>

               

            </div>

        </div>
    )
}