import { useEffect, useState } from "react"
import Sidebar from "../components/Sidebar"

export default function Profile() {

    const [user, setUser] = useState({
        name: "",
        email: "",
        college: ""
    })

    useEffect(() => {
        const savedUser = localStorage.getItem("user")

        if (savedUser) {
            setUser(JSON.parse(savedUser))
        }
    }, [])

    return (

        <div className="app-container">

            <Sidebar />

            <div className="main-content">

                <h1 className="text-2xl font-bold mb-4">Profile</h1>

                <div className="card">

                    <p><strong>Name:</strong> {user.name || "Not set"}</p>
                    <p><strong>Email:</strong> {user.email || "Not set"}</p>
                    <p><strong>College:</strong> {user.college || "Not set"}</p>
                    <p><strong>Phone:</strong> {user.phone || "Not set"}</p>

                </div>

            </div>

        </div>
    )
}