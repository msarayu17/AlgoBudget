import { useEffect, useState } from "react"
import Sidebar from "../components/Sidebar"

export default function Settings() {

    const [darkMode, setDarkMode] = useState(() => {
        return localStorage.getItem("darkMode") === "true"
    })

    // Apply dark mode to body
    useEffect(() => {
        if (darkMode) {
            document.body.classList.add("dark")
        } else {
            document.body.classList.remove("dark")
        }

        localStorage.setItem("darkMode", darkMode)
    }, [darkMode])

    return (

        <div className="app-container">

            <Sidebar />

            <div className="main-content">

                <h1 className="text-2xl font-bold mb-6">Settings</h1>

                <div className="card flex justify-between items-center">

                    <div>
                        <h3 className="font-semibold">Dark Mode</h3>
                        <p className="text-gray-500 text-sm">
                            Enable dark theme for better experience
                        </p>
                    </div>

                    <label className="toggle-switch">
                        <input
                            type="checkbox"
                            checked={darkMode}
                            onChange={() => setDarkMode(!darkMode)}
                        />
                        <span className="slider"></span>
                    </label>
                </div>

                <div className="card mt-6">
                    <h3 className="font-semibold">About</h3>
                    <p className="text-gray-600 mt-2">
                        AlgoBudget v1.0
                    </p>
                    <p className="text-gray-500 text-sm">
                        Smart Student Expense Tracker
                    </p>
                </div>

            </div>

        </div>
    )
}