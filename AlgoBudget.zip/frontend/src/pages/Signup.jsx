import { useState } from "react"
import { useNavigate } from "react-router-dom"

export default function Signup() {

    const navigate = useNavigate()

    const [name, setName] = useState("")
    const [college, setCollege] = useState("")
    const [phone, setPhone] = useState("")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [error, setError] = useState("")

    const handleSignup = async (e) => {
        e.preventDefault()

        if (!email.includes("@gmail.com")) {
            setError("Email must be a Gmail address")
            return
        }

        try {
            const response = await fetch("http://127.0.0.1:5000/signup", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    name,
                    email,
                    college,
                    phone,
                    password
                })
            })

            const data = await response.json() // ✅ MUST be before using data

            if (response.ok) {
                localStorage.setItem("user", JSON.stringify({ name, email, college, phone }))
                localStorage.setItem("email", email)
                navigate("/dashboard")
            } else {
                setError(data.error)
            }

        } catch (err) {
            
            setError("Server error")
        }
    }

    return (

        <div className="center-page">

            <div className="login-card">

                <h2>Sign up</h2>

                <form onSubmit={handleSignup}>

                    <input 
                        type="text"
                        placeholder="Enter Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    />

                    <input
                        type="text"
                        placeholder="Enter College"
                        value={college}
                        onChange={(e) => setCollege(e.target.value)}
                        required
                    />

                    <input
                        type="email"
                        placeholder="Enter Gmail"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />

                    <input
                        type="tel"
                        placeholder="Enter Phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        required
                    />

                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />

                    {error && <p className="error">{error}</p>}

                    <button type="submit">Sign Up</button>

                    <p style={{ fontSize: "15px", marginTop: "10px" }}>
                    
                        Already have an account?{" "}
                        <span
                            style={{ color: "blue", cursor: "pointer"}}
                            onClick={() => navigate("/login")}
                        >
                            Login
                        </span>
                    </p>

                </form>

            </div>

        </div>
    )
}