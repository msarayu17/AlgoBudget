import { useState } from "react"
import { BrowserRouter, Routes, Route } from "react-router-dom"

import Landing from "./pages/Landing"
import Signup from "./pages/Signup"
import Login from "./pages/Login"
import Dashboard from "./pages/Dashboard"
import Transactions from "./pages/Transactions"
import Reports from "./pages/Reports"
import Profile from "./pages/Profile"
import Settings from "./pages/Settings"

function App() {

  const [expenses, setExpenses] = useState([])

  const addExpense = (expense) => {
    const newExpense = {
      ...expense,
      id: Date.now(), // unique id
      date: new Date().toLocaleDateString() // auto date
    }

    setExpenses(prevExpenses => [...prevExpenses, newExpense])
  }

  return (

    <BrowserRouter>

      <Routes>

        <Route path="/" element={<Landing />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route
          path="/dashboard"
          element={<Dashboard addExpense={addExpense} />}
        />

        <Route
          path="/transactions"
          element={<Transactions expenses={expenses} />}
        />
        <Route path="/reports" element={<Reports />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/settings" element={<Settings />} />

      </Routes>

    </BrowserRouter>

  )

}

export default App