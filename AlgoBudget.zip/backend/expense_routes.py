from flask import Blueprint,request,jsonify
from db import connect_db

expense_bp = Blueprint("expense",__name__)

@expense_bp.route("/add-expense",methods=["POST"])

def add_expense():

    data=request.json

    conn=connect_db()
    cursor=conn.cursor()

    cursor.execute(
    "INSERT INTO expenses(amount,date,category) VALUES(%s,%s,%s)",
    (data["amount"],data["date"],data["category"])
    )

    conn.commit()

    return jsonify({"message":"Expense added"})