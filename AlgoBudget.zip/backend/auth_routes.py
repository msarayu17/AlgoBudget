from flask import Blueprint, request, jsonify
from db import get_db

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/signup", methods=["POST"])
def signup():
    print("Signup API HIT")

    data = request.json
    name = data.get("name")
    email = data.get("email")
    college = data.get("college")
    phone = data.get("phone")
    password = data.get("password")

    try:
        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO users (name, email, college, phone, password)
        VALUES (%s, %s, %s, %s, %s)
        """, (name, email, college, phone, password))

        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"message": "User registered successfully"}), 201

    except Exception as e:
        return jsonify({"error": "User already exists"}), 400
    
@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()

    email = data.get("email")
    password = data.get("password")

    db = get_db()
    cursor = db.cursor(dictionary=True)

    cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
    user = cursor.fetchone()

    if user:
        if user["password"] == password:
            return jsonify({
                "message": "Login successful",
                "user": {
                    "name": user["name"],
                    "email": user["email"],
                    "college": user["college"],
                    "phone": user["phone"]
                }
            }), 200
        else:
            return jsonify({"error": "Invalid password"}), 401
    else:
        return jsonify({"error": "User not found"}), 404