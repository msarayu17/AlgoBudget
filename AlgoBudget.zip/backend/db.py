import mysql.connector

def get_db():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",          # your MySQL username
        password="Macherlasarayu@2617",  # your MySQL password
        database="algobudget"
    )
    return conn