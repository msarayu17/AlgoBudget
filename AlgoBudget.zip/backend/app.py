from flask import Flask
from auth_routes import auth_bp
from flask_cors import CORS
from db import get_db
from flask import request, jsonify


app = Flask(__name__)
app.register_blueprint(auth_bp, url_prefix="/")
CORS(app)
app.run(host="0.0.0.0", port=5000, debug=True)

@app.route('/add-expense', methods=['POST'])
def add_expense():
    data = request.json()

    email = data.get('email')
    date = data.get('date')
    amount = data.get('amount')
    category = data.get('category')

    if not email or not date or not amount or not category:
        return jsonify({"error": "Missing fields"}), 400


    db = get_db()
    cursor = db.cursor()

    query = "INSERT INTO expenses (email, date, amount, category) VALUES (%s, %s, %s, %s)"
    values = (email, date, amount, category)

    cursor.execute(query, values)
    db.commit()

    return jsonify({"message": "Expense saved"})


@app.route('/get-expenses', methods=['GET'])
def get_expenses():
    email = request.args.get('email')

    db = get_db()
    cursor = db.cursor(dictionary=True)

    query = "SELECT date, category, amount FROM expenses WHERE email = %s"
    cursor.execute(query, (email,))

    results = cursor.fetchall()

    return jsonify(results)

if __name__ == "__main__":
    app.run(debug=True, port=5000)

